import { Routes, Route } from "react-router-dom";
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Footer from './components/Footer';
import CreateAccount from './pages/CreateAccount';
import RegistrationSuccess from './pages/RegistrationSuccess';
import EmailVerified from "./pages/EmailVerified";
import Login from "./pages/Login";
import Profile from "./pages/Profile";

function App() {
    return (
        <>
            <Header />
            <Routes>
                <Route path="/" element={
                    <>
                        <Hero />
                        <About />
                    </>
                } />
                <Route path="/create-account" element={<CreateAccount />} />
                <Route path="/registration-success" element={<RegistrationSuccess />} />
                <Route path="/email-verified" element={<EmailVerified />} />
                <Route path="/login" element={<Login />} />
                <Route path="/user/:username" element={<Profile />} />
            </Routes>
            <Footer />
        </>
    );
}

export default App;
