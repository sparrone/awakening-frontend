import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";

export default function Profile() {
    const { username } = useParams<{ username: string }>();
    const [createdAt, setCreatedAt] = useState<string | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const response = await fetch(`/api/users/${username}`, {
                    credentials: "include",
                });

                if (!response.ok) {
                    throw new Error("Profile not found");
                }

                const data = await response.json();
                setCreatedAt(data.createdAt);
            } catch (err) {
                setError((err as Error).message);
            } finally {
                setLoading(false);
            }
        };

        if (username) {
            fetchProfile();
        }
    }, [username]);

    if (loading) {
        return (
            <div className="min-h-screen bg-gray-900 text-white pt-24 px-6 flex justify-center">
                <p>Loading profile...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div className="min-h-screen bg-gray-900 text-white pt-24 px-6 flex justify-center">
                <p className="text-red-400">{error}</p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-900 text-white pt-24 px-6 flex justify-center">
            <div className="w-full max-w-4xl bg-black bg-opacity-70 rounded-lg shadow-lg p-8 space-y-8">
                {/* Profile Header */}
                <div className="text-center">
                    <h1 className="text-3xl font-bold text-yellow-400 mb-2">
                        {username}'s Profile
                    </h1>
                    <p className="text-gray-300">
                        Account created on:{" "}
                        <span className="text-gray-100">
                            {createdAt ? new Date(createdAt).toLocaleDateString() : "Unknown"}
                        </span>
                    </p>
                </div>

                {/* Content Sections */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Forum Posts */}
                    <div className="bg-gray-800 bg-opacity-90 p-6 rounded-lg shadow-md">
                        <h2 className="text-xl font-semibold text-yellow-400 mb-4">
                            Forum Posts
                        </h2>
                        <p className="text-gray-400">Posts will appear here...</p>
                    </div>

                    {/* High Scores */}
                    <div className="bg-gray-800 bg-opacity-90 p-6 rounded-lg shadow-md">
                        <h2 className="text-xl font-semibold text-yellow-400 mb-4">
                            High Scores
                        </h2>
                        <p className="text-gray-400">High scores will appear here...</p>
                    </div>
                </div>
            </div>
        </div>
    );
}
