// src/context/AuthProvider.tsx
import React, { useEffect, useState } from "react";
import { AuthContext, type AuthContextType } from "./AuthContext";

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [username, setUsername] = useState("");
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const checkSession = async () => {
            console.log("🔍 Checking session...");

            try {
                const res = await fetch("/api/me", {
                    method: "GET",
                    credentials: "include",
                });

                console.log("📡 Response from /api/me:", res.status);

                if (res.ok) {
                    const data = await res.json();
                    console.log("✅ Session valid. Logged in as:", data.username);
                    setUsername(data.username);
                    setIsLoggedIn(true);
                } else {
                    console.log("🚫 No valid session found.");
                }
            } catch (err) {
                console.error("⚠️ Session check failed:", err);
            } finally {
                console.log("🔄 Finished session check. Setting loading to false.");
                setLoading(false);
            }
        };

        checkSession();
    }, []);

    const login = async (username: string) => {
        console.log("👤 Login called. Setting username:", username);

        // Optimistic update
        setIsLoggedIn(true);
        setUsername(username);

        // Optional: re-validate session from backend
        try {
            const res = await fetch("/api/me", {
                method: "GET",
                credentials: "include",
            });
            if (!res.ok) {
                console.warn("⚠️ Backend did not confirm session after login.");
                setIsLoggedIn(false);
                setUsername("");
            }
        } catch (err) {
            console.error("❌ Failed to confirm login session:", err);
            setIsLoggedIn(false);
            setUsername("");
        }
    };

    const logout = async () => {
        console.log("👋 Logout called.");

        try {
            const res = await fetch("/api/auth/logout", {
                method: "POST",
                credentials: "include",
            });

            if (res.ok) {
                console.log("✅ Session successfully invalidated on backend.");
            } else {
                console.warn("⚠️ Logout request sent, but server responded with:", res.status);
            }
        } catch (err) {
            console.error("❌ Logout request failed:", err);
        }

        setIsLoggedIn(false);
        setUsername("");
    };

    const value: AuthContextType = {
        isLoggedIn,
        username,
        loading,
        login,
        logout,
    };

    return (
        <AuthContext.Provider value={value}>
            {!loading && children}
        </AuthContext.Provider>
    );
};